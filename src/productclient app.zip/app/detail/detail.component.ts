import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from 'src/models/product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
  product: Product;
  constructor(private _service: ProductService, private route: Router, private activatroute: ActivatedRoute) { }

  ngOnInit(): void {
    let id = this.activatroute.snapshot.params["id"];
    this._service.getProductbyId(id).subscribe(data=>
      {
        this.product = data;
      });
  }

}
